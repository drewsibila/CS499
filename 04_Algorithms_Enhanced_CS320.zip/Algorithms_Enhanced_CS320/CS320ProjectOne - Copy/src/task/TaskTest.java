package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TaskTest {

    private String repeat(char character, int times) {
        return new String(new char[times])
                .replace('\0', character);
    }

    @Test
    void validTaskIsCreated() {
        Task task = new Task(
                "T1",
                "Clean",
                "Clean the house");

        assertEquals("T1", task.getTaskId());
        assertEquals("Clean", task.getName());
        assertEquals(
                "Clean the house",
                task.getDescription());
    }

    @Test
    void taskIdRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        null,
                        "Name",
                        "Description"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        "TOO_LONG_ID",
                        "Name",
                        "Description"));
    }

    @Test
    void taskNameRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        "T1",
                        null,
                        "Description"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        "T1",
                        repeat('N', 21),
                        "Description"));
    }

    @Test
    void descriptionRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        "T1",
                        "Name",
                        null));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Task(
                        "T1",
                        "Name",
                        repeat('D', 51)));
    }

    @Test
    void boundaryValuesAreAccepted() {
        Task task = new Task(
                repeat('T', 10),
                repeat('N', 20),
                repeat('D', 50));

        assertEquals(10, task.getTaskId().length());
        assertEquals(20, task.getName().length());
        assertEquals(50, task.getDescription().length());
    }
}