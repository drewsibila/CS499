package task;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(
            String taskId,
            String name,
            String description) {

        validateId(taskId);

        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException(
                    "Task ID already exists");
        }

        Task task = new Task(
                taskId,
                name,
                description);

        tasks.put(taskId, task);
    }

    public void deleteTask(String taskId) {
        validateId(taskId);

        if (tasks.remove(taskId) == null) {
            throw new IllegalArgumentException(
                    "Task ID was not found");
        }
    }

    public Task getTask(String taskId) {
        validateId(taskId);

        Task task = tasks.get(taskId);

        if (task == null) {
            throw new IllegalArgumentException(
                    "Task ID was not found");
        }

        return task;
    }

    public void updateName(
            String taskId,
            String name) {

        getTask(taskId).setName(name);
    }

    public void updateDescription(
            String taskId,
            String description) {

        getTask(taskId).setDescription(description);
    }

    public List<Task> getTasksSortedByName() {
        List<Task> sortedTasks =
                new ArrayList<>(tasks.values());

        sortedTasks.sort(
                Comparator.comparing(Task::getName)
                        .thenComparing(Task::getTaskId));

        return sortedTasks;
    }

    public int getTaskCount() {
        return tasks.size();
    }

    private void validateId(String taskId) {
        if (taskId == null || taskId.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Task ID cannot be empty");
        }
    }
}