package task;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

    @Test
    void taskCanBeAddedAndRetrieved() {
        TaskService service = new TaskService();

        service.addTask(
                "T1",
                "Clean",
                "Clean the house");

        Task task = service.getTask("T1");

        assertEquals("Clean", task.getName());
        assertEquals(1, service.getTaskCount());
    }

    @Test
    void duplicateTaskIdIsRejected() {
        TaskService service = new TaskService();

        service.addTask(
                "T1",
                "Clean",
                "Clean the house");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addTask(
                        "T1",
                        "Cook",
                        "Cook dinner"));
    }

    @Test
    void taskCanBeDeleted() {
        TaskService service = new TaskService();

        service.addTask(
                "T1",
                "Clean",
                "Clean the house");

        service.deleteTask("T1");

        assertEquals(0, service.getTaskCount());

        assertThrows(
                IllegalArgumentException.class,
                () -> service.getTask("T1"));
    }

    @Test
    void deletingMissingTaskThrowsException() {
        TaskService service = new TaskService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteTask("X"));
    }

    @Test
    void taskCanBeUpdated() {
        TaskService service = new TaskService();

        service.addTask(
                "T1",
                "Clean",
                "Clean the house");

        service.updateName("T1", "Cook");
        service.updateDescription(
                "T1",
                "Cook dinner");

        Task task = service.getTask("T1");

        assertEquals("Cook", task.getName());
        assertEquals(
                "Cook dinner",
                task.getDescription());
    }

    @Test
    void tasksAreSortedByName() {
        TaskService service = new TaskService();

        service.addTask(
                "T1",
                "Wash",
                "Wash the car");

        service.addTask(
                "T2",
                "Cook",
                "Cook dinner");

        service.addTask(
                "T3",
                "Clean",
                "Clean the house");

        List<Task> sorted =
                service.getTasksSortedByName();

        assertEquals("Clean", sorted.get(0).getName());
        assertEquals("Cook", sorted.get(1).getName());
        assertEquals("Wash", sorted.get(2).getName());
    }

    @Test
    void emptyTaskIdIsRejected() {
        TaskService service = new TaskService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.getTask(""));
    }
}