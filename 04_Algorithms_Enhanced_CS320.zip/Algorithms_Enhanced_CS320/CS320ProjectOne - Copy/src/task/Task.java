package task;

public class Task {

    private final String taskId;
    private String name;
    private String description;

    public Task(
            String taskId,
            String name,
            String description) {

        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException(
                    "Task ID must not be null or longer than 10 characters");
        }

        this.taskId = taskId;
        setName(name);
        setDescription(description);
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException(
                    "Task name must not be null or longer than 20 characters");
        }

        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException(
                    "Task description must not be null or longer than 50 characters");
        }

        this.description = description;
    }
}