package contact;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void contactCanBeAddedAndRetrieved() {
        ContactService service = new ContactService();

        service.addContact(
                "C1",
                "John",
                "Smith",
                "1234567890",
                "Address One");

        Contact contact = service.getContact("C1");

        assertEquals("John", contact.getFirstName());
        assertEquals(1, service.getContactCount());
    }

    @Test
    void duplicateContactIdIsRejected() {
        ContactService service = new ContactService();

        service.addContact(
                "C1",
                "John",
                "Smith",
                "1234567890",
                "Address One");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addContact(
                        "C1",
                        "Jane",
                        "Doe",
                        "0987654321",
                        "Address Two"));
    }

    @Test
    void contactCanBeDeleted() {
        ContactService service = new ContactService();

        service.addContact(
                "C1",
                "John",
                "Smith",
                "1234567890",
                "Address One");

        service.deleteContact("C1");

        assertEquals(0, service.getContactCount());

        assertThrows(
                IllegalArgumentException.class,
                () -> service.getContact("C1"));
    }

    @Test
    void deletingMissingContactThrowsException() {
        ContactService service = new ContactService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteContact("X"));
    }

    @Test
    void contactCanBeUpdated() {
        ContactService service = new ContactService();

        service.addContact(
                "C1",
                "John",
                "Smith",
                "1234567890",
                "Address One");

        service.updateFirstName("C1", "Jane");
        service.updateLastName("C1", "Doe");
        service.updatePhone("C1", "0987654321");
        service.updateAddress("C1", "456 Oak Road");

        Contact contact = service.getContact("C1");

        assertEquals("Jane", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("0987654321", contact.getPhone());
        assertEquals("456 Oak Road", contact.getAddress());
    }

    @Test
    void contactsAreSortedByLastNameAndFirstName() {
        ContactService service = new ContactService();

        service.addContact(
                "C1",
                "John",
                "Smith",
                "1234567890",
                "Address One");

        service.addContact(
                "C2",
                "Jane",
                "Brown",
                "0987654321",
                "Address Two");

        service.addContact(
                "C3",
                "Adam",
                "Smith",
                "1112223333",
                "Address Three");

        List<Contact> sorted =
                service.getContactsSortedByLastName();

        assertEquals("Brown", sorted.get(0).getLastName());
        assertEquals("Adam", sorted.get(1).getFirstName());
        assertEquals("John", sorted.get(2).getFirstName());
    }

    @Test
    void emptyContactIdIsRejected() {
        ContactService service = new ContactService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.getContact(""));
    }
}