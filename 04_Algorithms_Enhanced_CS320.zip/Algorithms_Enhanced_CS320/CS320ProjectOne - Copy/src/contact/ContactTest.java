package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    private String repeat(char character, int times) {
        return new String(new char[times])
                .replace('\0', character);
    }

    @Test
    void validContactIsCreated() {
        Contact contact = new Contact(
                "1234567890",
                "John",
                "Doe",
                "1234567890",
                "123 Main Street");

        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void contactIdRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        null,
                        "John",
                        "Doe",
                        "1234567890",
                        "123 Main Street"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "TOO_LONG_ID",
                        "John",
                        "Doe",
                        "1234567890",
                        "123 Main Street"));
    }

    @Test
    void firstNameRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        null,
                        "Doe",
                        "1234567890",
                        "123 Main Street"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        repeat('F', 11),
                        "Doe",
                        "1234567890",
                        "123 Main Street"));
    }

    @Test
    void lastNameRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        "John",
                        null,
                        "1234567890",
                        "123 Main Street"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        "John",
                        repeat('L', 11),
                        "1234567890",
                        "123 Main Street"));
    }

    @Test
    void phoneRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        "John",
                        "Doe",
                        null,
                        "123 Main Street"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        "John",
                        "Doe",
                        "12345",
                        "123 Main Street"));
    }

    @Test
    void addressRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        "John",
                        "Doe",
                        "1234567890",
                        null));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Contact(
                        "C1",
                        "John",
                        "Doe",
                        "1234567890",
                        repeat('A', 31)));
    }

    @Test
    void boundaryValuesAreAccepted() {
        Contact contact = new Contact(
                repeat('C', 10),
                repeat('F', 10),
                repeat('L', 10),
                "0123456789",
                repeat('A', 30));

        assertEquals(10, contact.getContactId().length());
        assertEquals(10, contact.getFirstName().length());
        assertEquals(10, contact.getLastName().length());
        assertEquals(10, contact.getPhone().length());
        assertEquals(30, contact.getAddress().length());
    }
}