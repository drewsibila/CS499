package contact;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ContactService {

    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(
            String contactId,
            String firstName,
            String lastName,
            String phone,
            String address) {

        validateId(contactId);

        if (contacts.containsKey(contactId)) {
            throw new IllegalArgumentException(
                    "Contact ID already exists");
        }

        Contact contact = new Contact(
                contactId,
                firstName,
                lastName,
                phone,
                address);

        contacts.put(contactId, contact);
    }

    public void deleteContact(String contactId) {
        validateId(contactId);

        if (contacts.remove(contactId) == null) {
            throw new IllegalArgumentException(
                    "Contact ID was not found");
        }
    }

    public Contact getContact(String contactId) {
        validateId(contactId);

        Contact contact = contacts.get(contactId);

        if (contact == null) {
            throw new IllegalArgumentException(
                    "Contact ID was not found");
        }

        return contact;
    }

    public void updateFirstName(
            String contactId,
            String firstName) {

        getContact(contactId).setFirstName(firstName);
    }

    public void updateLastName(
            String contactId,
            String lastName) {

        getContact(contactId).setLastName(lastName);
    }

    public void updatePhone(
            String contactId,
            String phone) {

        getContact(contactId).setPhone(phone);
    }

    public void updateAddress(
            String contactId,
            String address) {

        getContact(contactId).setAddress(address);
    }

    public List<Contact> getContactsSortedByLastName() {
        List<Contact> sortedContacts =
                new ArrayList<>(contacts.values());

        sortedContacts.sort(
                Comparator.comparing(Contact::getLastName)
                        .thenComparing(Contact::getFirstName));

        return sortedContacts;
    }

    public int getContactCount() {
        return contacts.size();
    }

    private void validateId(String contactId) {
        if (contactId == null || contactId.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Contact ID cannot be empty");
        }
    }
}