package appointment;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class AppointmentService {

    private final Map<String, Appointment> appointments =
            new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException(
                    "Appointment cannot be null");
        }

        String appointmentId =
                appointment.getAppointmentID();

        validateId(appointmentId);

        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException(
                    "Appointment ID already exists");
        }

        appointments.put(
                appointmentId,
                appointment);
    }

    public void addAppointment(
            String appointmentId,
            Date date,
            String description) {

        addAppointment(
                new Appointment(
                        appointmentId,
                        date,
                        description));
    }

    public void deleteAppointment(String appointmentId) {
        validateId(appointmentId);

        if (appointments.remove(appointmentId) == null) {
            throw new IllegalArgumentException(
                    "Appointment ID was not found");
        }
    }

    public Appointment getAppointment(
            String appointmentId) {

        validateId(appointmentId);

        Appointment appointment =
                appointments.get(appointmentId);

        if (appointment == null) {
            throw new IllegalArgumentException(
                    "Appointment ID was not found");
        }

        return appointment;
    }

    public List<Appointment> getAppointmentsSortedByDate() {
        List<Appointment> sortedAppointments =
                new ArrayList<>(appointments.values());

        sortedAppointments.sort(
                Comparator.comparing(
                        Appointment::getAppointmentDate));

        return sortedAppointments;
    }

    public Appointment getNextAppointment() {
        if (appointments.isEmpty()) {
            throw new IllegalStateException(
                    "No appointments are available");
        }

        PriorityQueue<Appointment> queue =
                new PriorityQueue<>(
                        Comparator.comparing(
                                Appointment::getAppointmentDate));

        queue.addAll(appointments.values());

        return queue.peek();
    }

    public int getAppointmentCount() {
        return appointments.size();
    }

    private void validateId(String appointmentId) {
        if (appointmentId == null
                || appointmentId.trim().isEmpty()) {

            throw new IllegalArgumentException(
                    "Appointment ID cannot be empty");
        }
    }
}