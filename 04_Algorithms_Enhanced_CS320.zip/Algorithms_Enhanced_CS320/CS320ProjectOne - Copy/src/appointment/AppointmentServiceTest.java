package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    private Date futureDate(int daysFromNow) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, daysFromNow);
        return calendar.getTime();
    }

    @Test
    void appointmentCanBeAddedAndRetrieved() {
        AppointmentService service =
                new AppointmentService();

        service.addAppointment(
                "A1",
                futureDate(3),
                "Checkup");

        Appointment appointment =
                service.getAppointment("A1");

        assertEquals(
                "Checkup",
                appointment.getDescription());

        assertEquals(
                1,
                service.getAppointmentCount());
    }

    @Test
    void duplicateAppointmentIdIsRejected() {
        AppointmentService service =
                new AppointmentService();

        service.addAppointment(
                "A1",
                futureDate(3),
                "Checkup");

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(
                        "A1",
                        futureDate(4),
                        "Another appointment"));
    }

    @Test
    void nullAppointmentIsRejected() {
        AppointmentService service =
                new AppointmentService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(null));
    }

    @Test
    void appointmentCanBeDeleted() {
        AppointmentService service =
                new AppointmentService();

        service.addAppointment(
                "A1",
                futureDate(3),
                "Checkup");

        service.deleteAppointment("A1");

        assertEquals(
                0,
                service.getAppointmentCount());

        assertThrows(
                IllegalArgumentException.class,
                () -> service.getAppointment("A1"));
    }

    @Test
    void deletingMissingAppointmentThrowsException() {
        AppointmentService service =
                new AppointmentService();

        assertThrows(
                IllegalArgumentException.class,
                () -> service.deleteAppointment("X"));
    }

    @Test
    void appointmentsAreSortedByDate() {
        AppointmentService service =
                new AppointmentService();

        service.addAppointment(
                "A3",
                futureDate(10),
                "Third");

        service.addAppointment(
                "A1",
                futureDate(2),
                "First");

        service.addAppointment(
                "A2",
                futureDate(5),
                "Second");

        List<Appointment> sorted =
                service.getAppointmentsSortedByDate();

        assertEquals(
                "A1",
                sorted.get(0).getAppointmentID());

        assertEquals(
                "A2",
                sorted.get(1).getAppointmentID());

        assertEquals(
                "A3",
                sorted.get(2).getAppointmentID());
    }

    @Test
    void nextAppointmentUsesEarliestDate() {
        AppointmentService service =
                new AppointmentService();

        service.addAppointment(
                "A3",
                futureDate(10),
                "Third");

        service.addAppointment(
                "A1",
                futureDate(2),
                "First");

        service.addAppointment(
                "A2",
                futureDate(5),
                "Second");

        Appointment next =
                service.getNextAppointment();

        assertEquals(
                "A1",
                next.getAppointmentID());
    }

    @Test
    void nextAppointmentThrowsWhenEmpty() {
        AppointmentService service =
                new AppointmentService();

        assertThrows(
                IllegalStateException.class,
                service::getNextAppointment);
    }
}