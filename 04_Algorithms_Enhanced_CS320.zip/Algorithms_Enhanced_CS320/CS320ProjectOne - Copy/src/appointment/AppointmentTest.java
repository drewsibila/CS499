package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    private String repeat(char character, int times) {
        return new String(new char[times])
                .replace('\0', character);
    }

    private Date futureDate(int daysFromNow) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, daysFromNow);
        return calendar.getTime();
    }

    @Test
    void validAppointmentIsCreated() {
        Appointment appointment = new Appointment(
                "A1",
                futureDate(1),
                "Checkup");

        assertEquals(
                "A1",
                appointment.getAppointmentID());

        assertEquals(
                "Checkup",
                appointment.getDescription());
    }

    @Test
    void appointmentIdRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        null,
                        futureDate(1),
                        "Description"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "TOO_LONG_ID",
                        futureDate(1),
                        "Description"));
    }

    @Test
    void appointmentDateRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "A1",
                        null,
                        "Description"));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "A1",
                        futureDate(-1),
                        "Description"));
    }

    @Test
    void descriptionRulesAreEnforced() {
        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "A1",
                        futureDate(1),
                        null));

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "A1",
                        futureDate(1),
                        repeat('D', 51)));
    }

    @Test
    void boundaryValuesAreAccepted() {
        Appointment appointment = new Appointment(
                repeat('A', 10),
                futureDate(1),
                repeat('D', 50));

        assertEquals(
                10,
                appointment.getAppointmentID().length());

        assertEquals(
                50,
                appointment.getDescription().length());
    }

    @Test
    void appointmentDateUsesDefensiveCopy() {
        Date originalDate = futureDate(5);

        Appointment appointment = new Appointment(
                "A1",
                originalDate,
                "Checkup");

        long savedTime =
                appointment.getAppointmentDate().getTime();

        originalDate.setTime(0);

        assertEquals(
                savedTime,
                appointment.getAppointmentDate().getTime());

        Date returnedDate =
                appointment.getAppointmentDate();

        returnedDate.setTime(0);

        assertEquals(
                savedTime,
                appointment.getAppointmentDate().getTime());
    }
}