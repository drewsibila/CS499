package contact;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import org.junit.jupiter.api.Test;

class ContactTest {

    private String repeat(char c, int times) {
        return new String(new char[times]).replace('\0', c);
    }

    @Test
    void testContactClass() {
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main Street");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void contactIdRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("TOO_LONG_ID", "John", "Doe", "1234567890", "123 Main Street"));
    }

    @Test
    void firstNameRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", null, "Doe", "1234567890", "123 Main Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", repeat('F', 11), "Doe", "1234567890", "123 Main Street"));
    }

    @Test
    void lastNameRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", null, "1234567890", "123 Main Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", repeat('L', 11), "1234567890", "123 Main Street"));
    }

    @Test
    void phoneRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", null, "123 Main Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", "12345", "123 Main Street"));
    }

    @Test
    void addressRules() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", "1234567890", repeat('A', 31)));
    }

    @Test
    void boundaryValuesAreAccepted() {
        String id10 = repeat('C', 10);
        String first10 = repeat('F', 10);
        String last10 = repeat('L', 10);
        String phone10 = "0123456789";
        String address30 = repeat('A', 30);

        Contact c = new Contact(id10, first10, last10, phone10, address30);
        assertEquals(10, c.getContactId().length());
        assertEquals(10, c.getFirstName().length());
        assertEquals(10, c.getLastName().length());
        assertEquals(10, c.getPhone().length());
        assertEquals(30, c.getAddress().length());
    }
}
