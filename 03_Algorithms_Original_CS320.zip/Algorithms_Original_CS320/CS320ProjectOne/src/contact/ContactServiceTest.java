package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    void addAndGetContact() {
        ContactService svc = new ContactService();
        svc.addContact("C1", "John", "Smith", "1234567890", "addr");
        Contact c = svc.get("C1");
        assertEquals("John", c.getFirstName());
    }

    @Test
    void cannotAddDuplicateId() {
        ContactService svc = new ContactService();
        svc.addContact("C1", "John", "Smith", "1234567890", "addr");
        assertThrows(IllegalArgumentException.class,
                () -> svc.addContact("C1", "Jane", "Doe", "0987654321", "addr2"));
    }

    @Test
    void deleteContact() {
        ContactService svc = new ContactService();
        svc.addContact("C1", "John", "Smith", "1234567890", "addr");
        svc.deleteContact("C1");
        assertThrows(IllegalArgumentException.class, () -> svc.get("C1"));
    }

    @Test
    void deleteMissingThrows() {
        ContactService svc = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> svc.deleteContact("X"));
    }

    @Test
    void updatesWork() {
        ContactService svc = new ContactService();
        svc.addContact("C1", "John", "Smith", "1234567890", "addr");
        svc.updateFirstName("C1", "Jane");
        svc.updateLastName("C1", "Doe");
        svc.updatePhone("C1", "0987654321");
        svc.updateAddress("C1", "456 Oak Road");
        Contact c = svc.get("C1");
        assertEquals("Jane", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("456 Oak Road", c.getAddress());
    }

    @Test
    void updateMissingThrows() {
        ContactService svc = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> svc.updateFirstName("X", "A"));
    }
}
