package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    private String repeat(char c, int times) {
        return new String(new char[times]).replace('\0', c);
    }

    @Test
    void idRules() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("TOO_LONG_ID", "Name", "Description"));
    }

    @Test
    void nameRules() {
        assertThrows(IllegalArgumentException.class, () -> new Task("ID123", null, "Description"));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID123", repeat('N', 21), "Description"));
    }

    @Test
    void descriptionRules() {
        assertThrows(IllegalArgumentException.class, () -> new Task("ID123", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("ID123", "Name", repeat('D', 51)));
    }

    @Test
    void boundaryTaskIsValid() {
        String id10 = repeat('T', 10);
        String name20 = repeat('N', 20);
        String desc50 = repeat('D', 50);

        Task t = new Task(id10, name20, desc50);
        assertEquals(10, t.getTaskId().length());
        assertEquals(20, t.getName().length());
        assertEquals(50, t.getDescription().length());
    }
}
