package task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(String taskId, String name, String description) {
        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Duplicate taskId");
        }
        tasks.put(taskId, new Task(taskId, name, description));
    }

    public void deleteTask(String taskId) {
        if (!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        Task t = get(taskId);
        t.setName(name);
    }

    public void updateDescription(String taskId, String description) {
        Task t = get(taskId);
        t.setDescription(description);
    }

    public Task get(String taskId) {
        Task t = tasks.get(taskId);
        if (t == null) {
            throw new IllegalArgumentException("Task not found");
        }
        return t;
    }
}
