package task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void addAndGetTask() {
        TaskService svc = new TaskService();
        svc.addTask("T1", "Clean", "Clean the house");
        Task t = svc.get("T1");
        assertEquals("Clean", t.getName());
    }

    @Test
    void cannotAddDuplicateId() {
        TaskService svc = new TaskService();
        svc.addTask("T1", "Clean", "Clean the house");
        assertThrows(IllegalArgumentException.class, () -> svc.addTask("T1", "Cook", "Cook dinner"));
    }

    @Test
    void deleteTask() {
        TaskService svc = new TaskService();
        svc.addTask("T1", "Clean", "Clean the house");
        svc.deleteTask("T1");
        assertThrows(IllegalArgumentException.class, () -> svc.get("T1"));
    }

    @Test
    void deleteMissingThrows() {
        TaskService svc = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> svc.deleteTask("X"));
    }

    @Test
    void updatesWork() {
        TaskService svc = new TaskService();
        svc.addTask("T1", "Clean", "Clean the house");
        svc.updateName("T1", "Cook");
        svc.updateDescription("T1", "Cook dinner");
        Task t = svc.get("T1");
        assertEquals("Cook", t.getName());
        assertEquals("Cook dinner", t.getDescription());
    }
}
