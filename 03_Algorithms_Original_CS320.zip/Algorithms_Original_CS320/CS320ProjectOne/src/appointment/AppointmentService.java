package appointment;

import java.util.HashMap;
import java.util.Map;
import java.util.Date;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentID())) {
            throw new IllegalArgumentException("Duplicate ID");
        }
        appointments.put(appointment.getAppointmentID(), appointment);
    }

    public void addAppointment(String appointmentID, Date date, String description) {
        addAppointment(new Appointment(appointmentID, date, description));
    }

    public void deleteAppointment(String appointmentID) {
        if (!appointments.containsKey(appointmentID)) {
            throw new IllegalArgumentException("Appointment not found");
        }
        appointments.remove(appointmentID);
    }

    public Appointment get(String appointmentID) {
        return appointments.get(appointmentID);
    }
}
