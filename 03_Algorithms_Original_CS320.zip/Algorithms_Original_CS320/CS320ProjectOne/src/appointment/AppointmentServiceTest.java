package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    @Test
    void addGetAndDeleteAppointment() {
        AppointmentService svc = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 3);
        Appointment a = new Appointment("A1", cal.getTime(), "Checkup");

        svc.addAppointment(a);
        assertEquals(a, svc.get("A1"));

        svc.deleteAppointment("A1");
        assertNull(svc.get("A1"));
    }

    @Test
    void addWithParamsAndDuplicateCheck() {
        AppointmentService svc = new AppointmentService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 4);

        svc.addAppointment("A1", cal.getTime(), "Haircut");
        assertThrows(IllegalArgumentException.class,
                () -> svc.addAppointment("A1", cal.getTime(), "Another"));
    }

    @Test
    void deleteMissingThrows() {
        AppointmentService svc = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> svc.deleteAppointment("X"));
    }
}
