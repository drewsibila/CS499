package appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Test;

class AppointmentTest {

    private String repeat(char c, int times) {
        return new String(new char[times]).replace('\0', c);
    }

    @Test
    void idRules() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date future = cal.getTime();
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future, "X"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("TOO_LONG_ID", future, "X"));
    }

    @Test
    void dateMustNotBePast() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date past = cal.getTime();
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", past, "X"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", null, "X"));
    }

    @Test
    void descriptionRules() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date future = cal.getTime();
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", future, null));
        String longDesc = repeat('D', 51);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("A1", future, longDesc));
    }

    @Test
    void boundaryAppointmentIsValid() {
        String id10 = repeat('A', 10);
        String desc50 = repeat('D', 50);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1); // tomorrow
        Date future = cal.getTime();

        Appointment a = new Appointment(id10, future, desc50);
        assertEquals(10, a.getAppointmentID().length());
        assertEquals(50, a.getDescription().length());
    }
}
